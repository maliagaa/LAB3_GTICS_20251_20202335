CREATE DATABASE Mundial;
USE Mundial; 

CREATE TABLE jugador (
	idJugador INT PRIMARY KEY,
    nombre VARCHAR(45),
    edad INT,
    posicion VARCHAR(45),
    m_idSeleccion INT,
    FOREIGN KEY (m_idSeleccion) REFERENCES selecticcion(idSeleccion)
);

CREATE TABLE seleccion (
	idSeleccion INT PRIMARY KEY,
    nombre VARCHAR(45),
    tecnico VARCHAR(45),
    estadios_idEstadios INT,
    FOREIGN KEY (estadios_idEstadios) REFERENCES estadio(idEstadio)
);

CREATE TABLE estadio (
	idPartido INT PRIMARY KEY,
    nombre VARCHAR(45),
    provincia VARCHAR(45),
    club VARCHAR(45)
);

CREATE TABLE arbitro (
	idArbitro INT PRIMARY KEY,
    nombre VARCHAR(45),
    pais VARCHAR(45)
);

CREATE TABLE partido (
	idPartido INT PRIMARY KEY,
    fecha DATE,
    num_jornada INT,
    seleccionLocal INT,
    seleccionVisitante INT,
    arbitro INT,
    FOREIGN KEY (seleccionLocal) REFERENCES seleccion(idSeleccion),
    FOREIGN KEY (seleccionVisitante) REFERENCES seleccion(idSeleccion),
    FOREIGN KEY (arbitro) REFERENCES seleccion(idArbitro)
);

    

