package com.mundialapp.mundial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MundialApplicationTests {

	@Test
	void contextLoads() {
	}

}
