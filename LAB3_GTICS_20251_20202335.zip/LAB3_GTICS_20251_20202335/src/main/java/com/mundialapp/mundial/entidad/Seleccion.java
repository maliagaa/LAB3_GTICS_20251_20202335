package com.mundialapp.mundial.entidad;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Seleccion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSeleccion;

    private String nombre;
    private String tecnico;

    @OneToMany(mappedBy = "seleccion")
    private List<Jugador>jugadores;

    public Integer getIdSeleccion() {
        return idSeleccion;
    }
    public void setIdSeleccion(Integer idSeleccion) {
        this.idSeleccion = idSeleccion;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getTecnico() {
        return tecnico;
    }
    public void setTecnico(String tecnico) {
        this.tecnico = tecnico;
    }
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    public void setJugadores(List<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

}